import pandas as pd
import numpy as np
from sklearn.cross_validation import train_test_split
from xgboost import XGBRegressor
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import accuracy_score
from sklearn.ensemble import ExtraTreesRegressor,GradientBoostingRegressor
import lightgbm as lgb
def handle_non_numerical_data(df):
    columns = df.columns.values
    for column in columns:
        text_digit_vals = {}
        def convert_to_int(val):
            return text_digit_vals[val]

        if df[column].dtype != np.int64 and df[column].dtype != np.float64:
            column_contents = df[column].values.tolist()
            unique_elements = set(column_contents)
            x = 0
            for unique in unique_elements:
                if unique not in text_digit_vals:
                    text_digit_vals[unique] = x
                    x+=1

            df[column] = list(map(convert_to_int, df[column]))

    return df

train= pd.read_csv("train_NIR5Yl1.csv")
#print(train.head())
train=handle_non_numerical_data(train)
#print("After converting  categorical data into numerical")
#print(train.head())



#print(test.head())

target=train['Upvotes']
target = pd.DataFrame({'Upvotes': target})

train=train.drop('ID',1)
train=train.drop('Upvotes',1)
train=train.fillna(0)
#print(target)
print("here")

a_train, a_valid, b_train, b_valid = train_test_split(train, target, test_size=0.4,random_state=500)
#--------------------------------------
clf=ExtraTreesRegressor(n_estimators=500,criterion='mse',max_depth=100,random_state=12)
clf.fit(a_train,b_train)
#----------------------------------------																																					
aa=clf.predict(a_valid)
one=(aa.tolist())
two=(np.array(b_valid['Upvotes'])).tolist()
#print(two)
#print(one)
print(mean_absolute_error(two,one))
train=[]
a_train=[]
a_valid=[]
b_train=[]
b_valid=[]

print("train_done")

test= pd.read_csv("test_8i3B3FC.csv")
test=test.sort_values('ID')
test=handle_non_numerical_data(test)
#test=test.sort_values(['S_No'],ascending=True)
#print(test.head())
#print(test.head())

#test = test.drop('Sales', 1)
test = test.drop('ID', 1)
test=test.fillna(0)

Y_pred = clf.predict(test)


test=[]
print("predict_done")


result= pd.read_csv("sample_submission_OR5kZa5.csv")
#print(Y_pred)
result=result.drop('Upvotes',1)
#result=result.drop('S_No',1)

result["Upvotes"]=Y_pred
#print(test.head())

#print((valid))
#print(Y_pred)

#compare = pd.DataFrame({'Sales_real':b_valid,'Sales_predicted':Y_pred})

#print(compare)

result.to_csv('submit1.csv',index=False)
