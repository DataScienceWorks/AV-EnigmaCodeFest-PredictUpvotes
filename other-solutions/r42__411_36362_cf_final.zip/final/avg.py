import pandas as pd
import numpy as np


sub1 = pd.read_csv("submit1.csv")
sub2 = pd.read_csv("submit2.csv")


sub1["Upvotes2"]=sub2["Upvotes"]


sub1['Upvotes3'] = sub1[['Upvotes', 'Upvotes2']].mean(axis=1)

sub1=sub1.drop('Upvotes',1)
sub1=sub1.drop('Upvotes2',1)
sub1["Upvotes"]=sub1["Upvotes3"]
sub1=sub1.drop('Upvotes3',1)

sub1.to_csv('submit3.csv',index=False)

