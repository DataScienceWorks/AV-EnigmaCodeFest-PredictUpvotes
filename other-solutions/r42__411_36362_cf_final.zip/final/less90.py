import pandas as pd
import numpy as np


sub1 = pd.read_csv("submit1.csv")
sub2 = pd.read_csv("submit2.csv")

a=sub1[sub1["Upvotes"]<90]
b=sub2[sub1["Upvotes"]>=90]

c=pd.concat([a,b],sort=False)
c=c.sort_values('ID')


c.to_csv('submit4.csv',index=False)

