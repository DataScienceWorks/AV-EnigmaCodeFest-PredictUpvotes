1) Run extree.py (submit1.csv will create)
	-- python extree.py
2) Run rtf.py (submit2.csv will create)
	-- python rtf.py
3) Run avg.py (submit3.csv will create)
	-- python avg.py
4) Run less90.py (submit4.csv will create)
	-- python less90.py
5) Run avg2.py (submit_final.csv will create)
	-- python avg2.py

The final results file is submit_final.csv

